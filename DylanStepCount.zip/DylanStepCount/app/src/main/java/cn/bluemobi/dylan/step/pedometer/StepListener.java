package cn.bluemobi.dylan.step.pedometer;
public interface StepListener {
    public void onStep();
}