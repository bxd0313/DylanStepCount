package cn.bluemobi.dylan.step.step.accelerometer;

/**
 * Created by dylan on 16/9/27.
 */
public interface StepCountListener {
    void countStep();
}
