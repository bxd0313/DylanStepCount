package cn.bluemobi.dylan.step.step.config;

/**
 * Created by dylan on 2016/1/30.
 */
public class Constant {
    public static final int MSG_FROM_CLIENT = 0;
    public static final int MSG_FROM_SERVER = 1;
    public static final int REQUEST_SERVER = 2;
}
